<?php /*Created by PhpStorm.*/ ?>
<?php /*User: rodrigo*/ ?>
<?php /*Date: 08/07/16*/ ?>
<?php /*Time: 09:06*/ ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 ps-page-header">
            <h1><span class="glyphicon glyphicon-indent-right" aria-hidden="true"></span>Painel de Controle - Adicionar Membro</h1>
        </div>
    </div>
    <form action="<?php echo e(route('membro-adiciona')); ?>"method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row form-group">
            <div class="col-md-4">
                <label>Nome:</label>
                <input type="text" name="nome" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Data de Nascimento:</label>
                <input type="text" name="nascimento" placeholder="Ex: <?php echo e(date('d/m/Y',strtotime('now'))); ?>" id="nascimento" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label>Sexo:</label>
                <select name="sexo" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($sexo as $s): ?>
                        <option value="<?php echo e($s->id); ?>"><?php echo e($s->descricao); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label>Estado Civil:</label>
                <select name="estado_civil" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($estado as $e): ?>
                        <option value="<?php echo e($e->id); ?>"><?php echo e($e->descricao); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-3">
                <label>Endereço:</label>
                <input type="text" name="endereco" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Bairro:</label>
                <input type="text" name="bairro" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Numero:</label>
                <input type="text" name="numero"  id="numero" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>CEP:</label>
                <input type="text" name="cep"  id="cep" placeholder="EX: 00.000-000" class="form-control" required>
            </div>
            <div class="col-md-3">
                <label>Municipio:</label>
                <select name="municipio" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($municipio as $m): ?>
                        <option value="<?php echo e($m->id); ?>"><?php echo e($m->nome); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-2">
                <label>CPF:</label>
                <input type="text" name="cpf" placeholder="Ex: 000.000.000-00" id="cpf" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>RG:</label>
                <input type="text" name="rg" placeholder="Ex: 000.000.000" id="rg" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Telefone:</label>
                <input type="text" name="fone" id="fone" placeholder="Ex: (00) 00000-0000" class="form-control" required>
            </div>
            <div class="col-md-2">
                <label>Email:</label>
                <input type="text" name="email" id="email" placeholder="Ex: igreja@igreja.com.br" class="form-control" required>
            </div>

            <div class="col-md-2">
                <label>Grau de Instrução:</label>
                <select name="grau" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($grau as $g): ?>
                        <option value="<?php echo e($g->id); ?>"><?php echo e($g->descricao); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Profissão:</label>
                <input type="text" name="profissao" placeholder="Ex: Pedreiro ou Advogado" class="form-control" required>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-4">
                <label>Igreja que Congrego:</label>
                <select name="igreja" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($igreja as $i): ?>
                        <option value="<?php echo e($i->id); ?>"><?php echo e($i->razao_social); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Nome da Mãe:</label>
                <input type="text" name="nome_mae"  id="nascimento" class="form-control" required>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-md-2">
                    <a href="<?php echo e(route('membro-index')); ?>"class="btn btn-default">Cancelar</a>
                </div>
                <div class="col-md-10 text-right">
                    <button class="btn btn-success">Salvar Alterações</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function() {
            $("#nascimento").mask("99/99/9999");
            $("#cep").mask("99.999-999");
            $("#cpf").mask("999.999.999-99");
            $("#fone").mask("(99) 99999-9999");
            $("#rg").mask("999.999.999");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>