<?php /*Created by PhpStorm.*/ ?>
<?php /*User: rodrigo*/ ?>
<?php /*Date: 08/07/16*/ ?>
<?php /*Time: 13:04*/ ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 ps-page-header">
            <h1><span class="glyphicon glyphicon-certificate" aria-hidden="true"></span>Painel de Controle - Adicionar Missa</h1>
        </div>
    </div>
    <form action="<?php echo e(route('membro-adiciona')); ?>"method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row form-group">
            <div class="col-md-4">
                <label>Padre:</label>
                <select name="padre" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($padre as $p): ?>
                        <option value="<?php echo e($p->id); ?>"><?php echo e($p->nome); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Igreja:</label>
                <select name="igreja" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($igreja as $i): ?>
                        <option value="<?php echo e($i->id); ?>"><?php echo e($i->razao_social); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Diácono:</label>
                <input type="text" name="diacono" class="form-control" required>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-4">
                <label>Data da Missa:</label>
                <input type="text" name="data_missa" id="data_missa" class="form-control" required>
            </div>
            <div class="col-md-4">
                <label>Dia da Semana:</label>
                <select name="dia_semana" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($semana as $s): ?>
                        <option value="<?php echo e($s->id); ?>"><?php echo e($s->descricao); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Hora da Missa:</label>
                <input type="text" name="horario" id="horario" class="form-control" required>
            </div>
        </div>
        <div class="row form-group">
            <div class="col-md-4">
                <label>Total do Dizimo:</label>
                <input type="text" name="total_dizimo" class="form-control mask-money" required>
            </div>
            <div class="col-md-4">
                <label>Total do Oferta:</label>
                <input type="text" name="total_oferta" class="form-control mask-money" required>
            </div>
            <div class="col-md-4">
                <label>Total Arrecadado:</label>
                <input type="text" name="total_arrecadacao"  class="form-control mask-money" required>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-md-2">
                    <a href="<?php echo e(route('missa-index')); ?>"class="btn btn-default">Cancelar</a>
                </div>
                <div class="col-md-10 text-right">
                    <button class="btn btn-success">Salvar Alterações</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function() {
            $("#data_missa").mask("99/99/9999");
            $("#horario").mask("99:99");
            $(".mask-money").maskMoney({symbol:'R$ ',
                showSymbol:true, thousands:'.', decimal:',', symbolStay: true});
        })
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>