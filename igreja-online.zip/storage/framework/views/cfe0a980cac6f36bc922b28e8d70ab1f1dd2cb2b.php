<?php /*Created by PhpStorm.*/ ?>
<?php /*User: rodrigo*/ ?>
<?php /*Date: 08/07/16*/ ?>
<?php /*Time: 08:58*/ ?>

<?php $__env->startSection('head'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 ps-page-header">
            <h1><span class="glyphicon glyphicon-indent-right" aria-hidden="true"></span>Painel de Controle - Missa</h1>
        </div>
    </div>
    <div class="col-md-12">
        <h4>
            <a href="<?php echo e(route('missa-create')); ?>" class="btn btn-primary pull-right"><i class="glyphicon glyphicon-plus"></i> Adicionar Membro</a>
        </h4>
    </div>
    <div class="row">
        <div class="col-md-12 ps-page-header">
            <h1>Lista de Missas Registrados</h1>
        </div>
        <?php /*<div class="form-group col-md-12">*/ ?>
            <?php /*<?php foreach($model as $m): ?>*/ ?>
                <?php /*<div class="panel panel-default">*/ ?>
                    <?php /*<div class="panel-body">*/ ?>
                        <?php /*<div class="row">*/ ?>
                            <?php /*<p class="col-md-10">*/ ?>
                                <?php /*Nome: <span><?php echo e($m->nome); ?></span> <br>*/ ?>
                                <?php /*Nascimento: <span><?php echo e($m->nascimento); ?></span> <br>*/ ?>
                                <?php /*Profissão: <span><?php echo e($m->profissao); ?></span> <br>*/ ?>
                                <?php /*Igreja: <span><?php echo e($m->MembroIgreja->razao_social); ?></span> <br>*/ ?>
                            <?php /*</p>*/ ?>
                            <?php /*<div class="col-md-2 col-xs-6">*/ ?>
                                <?php /*<a href="<?php echo e(route('missa-edit', ['id' => $m->id])); ?>"class="btn btn-sm btn-block btn-warning"><i class="glyphicon glyphicon-edit"></i> Editar</a>*/ ?>
                            <?php /*</div>*/ ?>
                        <?php /*</div>*/ ?>
                    <?php /*</div>*/ ?>
                <?php /*</div>*/ ?>
            <?php /*<?php endforeach; ?>*/ ?>
        <?php /*</div>*/ ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>