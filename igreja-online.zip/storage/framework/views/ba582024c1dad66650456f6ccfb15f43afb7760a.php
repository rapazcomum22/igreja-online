<?php /*Created by PhpStorm.*/ ?>
<?php /*User: rodrigo*/ ?>
<?php /*Date: 08/07/16*/ ?>
<?php /*Time: 12:26*/ ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 ps-page-header">
            <h1><span class="glyphicon glyphicon-indent-right" aria-hidden="true"></span>Painel de Controle - Adicionar Membro</h1>
        </div>
    </div>
    <form action="<?php echo e(route('padre-update', ['id'=>$model->id])); ?>" method="post">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <div class="row form-group">
            <div class="col-md-4">
                <label>Igreja:</label>
                <select name="igreja" class="form-control">
                    <option value="#">Selecione...</option>
                    <?php foreach($igreja as $i): ?>
                        <option value="<?php echo e($i->id); ?>" <?php echo e($model->id_igreja == $i->id  ? 'selected' : ''); ?>><?php echo e($i->razao_social); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Nome:</label>
                <input type="text" name="nome" class="form-control" value="<?php echo e($model->nome); ?>" required>
            </div>
            <div class="col-md-4">
                <label>Data que Ingressou na Igreja:</label>
                <input type="text" name="data" placeholder="Ex: <?php echo e(date('d/m/Y',strtotime('now'))); ?>" id="data" value="<?php echo e($model->data); ?>" class="form-control" required>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-body">
                <div class="col-md-2">
                    <a href="<?php echo e(route('padre-index')); ?>"class="btn btn-default">Cancelar</a>
                </div>
                <div class="col-md-10 text-right">
                    <button class="btn btn-success">Salvar Alterações</button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(function() {
            $("#data").mask("99/99/9999");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>